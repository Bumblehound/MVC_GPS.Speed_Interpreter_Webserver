﻿using EntityFrameworkAccessLibrary.DataAccess;
using EntityFrameworkAccessLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace EntityFrameworkAccessLibrary.Logic
{
    public class DataProcessor
    {
        //ToDo
        //public static int CreateNewRoadSpeed(int roadId, int speed)
        //{
            //RoadSpeedModel data = new RoadSpeedModel{
                //Time = 56mins on tim's video
            //}
        //}
        public static List<GPS_All_DataModel> LoadAllData()
        {
            string sql = @"select s.Id, t.Datetime, s.Speed, l.Longitude, l.Latitude from dbo.GPSLog_Speed as s inner join dbo.GPSLog_Location as l on s.Id = l.Id inner join dbo.GPSLog_RecordedTime as t on s.Id = t.Id";

            return SQLServer_Access.LoadData<GPS_All_DataModel>(sql);
        }
        public static int LoadMaxSpeed()
        {
            string sql = @"select top(1) * from GPSLog_Speed order by Speed desc";

            return SQLServer_Access.LoadMaxSpeed(sql);
        }
        public static List<GPS_All_DataModel> LoadRecentJourney(DateTime date)
        {
            string sql = $@"select s.Id, t.Datetime, s.Speed, l.Longitude, l.Latitude, j.GPSLog_JourneyId
                            from GPSLog_Speed
                            as s
                            inner join dbo.GPSLog_Location
                            as l on s.Id = l.Id
                            inner join dbo.GPSLog_RecordedTime
                            as t on s.Id = t.Id
                            inner join dbo.GPSLog_JourneyId
                            as j on s.Id = j.Id
                            where CONVERT(DATE, DateTime) = '{date}'
                            order by DateTime desc";

            return SQLServer_Access.LoadRecentJourney<GPS_All_DataModel>(sql);
        }

    }
}
