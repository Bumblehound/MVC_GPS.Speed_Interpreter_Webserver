﻿using EntityFrameworkAccessLibrary.Models;
using Dapper;
using System.Configuration;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Diagnostics;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Linq;

namespace EntityFrameworkAccessLibrary.DataAccess
{
    public static class SQLServer_Access
    {
        public static IConfigurationRoot Configuration;
        public static string GetConnectionString(string connectionName = "default")
        {
            var builder = new ConfigurationBuilder()
               .SetBasePath(Directory.GetCurrentDirectory())
               .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
            return Configuration["ConnectionStrings:default"];
            //return System.Configuration.ConfigurationManager.ConnectionStrings[connectionName].ToString();//Returns ConnStr from Web.Config

        }

        public static List<T> LoadData<T>(string sql)
        {
            using(IDbConnection cnn = new SqlConnection(GetConnectionString()))
            {
                return cnn.Query<T>(sql).ToList();
            }
        }
        public static int LoadMaxSpeed(string sql)
        {
            using (IDbConnection cnn = new SqlConnection(GetConnectionString()))
            {
                return cnn.Query<GPS_Speed_Model>(sql).ToList()[0].Speed; 
            }
        }
        public static List<T> LoadRecentJourney<T>(string sql)
        {
            using (IDbConnection cnn = new SqlConnection(GetConnectionString()))
            {
                return cnn.Query<T>(sql).ToList();
            }
        }
        public static int SaveData<T>(string sql, T data)
        {
            using (IDbConnection cnn = new SqlConnection(GetConnectionString()))
            {
                return cnn.Execute(sql, data);
            }
        }
    }
}
