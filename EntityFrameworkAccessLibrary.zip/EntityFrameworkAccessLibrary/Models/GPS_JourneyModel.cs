﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntityFrameworkAccessLibrary.Models
{
    class GPS_JourneyModel
    {
        public string Id { get; set; }
        public string GPSLog_JourneyId { get; set; }


    }
}
