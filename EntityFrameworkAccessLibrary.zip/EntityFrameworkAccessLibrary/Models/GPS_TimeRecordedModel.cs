﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntityFrameworkAccessLibrary.Models
{
    class GPS_TimeRecordedModel
    {
        public string Id { get; set; }
        public string DateTime { get; set; }
    }
}
