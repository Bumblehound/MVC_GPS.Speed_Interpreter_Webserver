﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace EntityFrameworkAccessLibrary.Models
{
    public class GPS_Speed_Model
    {
        public string Id { get; set; }
        public int Speed { get; set; }

    }
}
