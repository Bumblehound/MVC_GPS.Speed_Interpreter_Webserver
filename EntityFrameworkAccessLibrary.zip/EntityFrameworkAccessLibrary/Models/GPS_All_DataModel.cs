﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntityFrameworkAccessLibrary.Models
{
    public class GPS_All_DataModel
    {
        //Prop Names must match db column names
        public string Id { get; set; }
        public string GPSLog_JourneyId { get; set; }
        public string DateTime { get; set; }
        public  int Speed { get; set; }
        public float Longitude { get; set; }
        public float Latitude { get; set; }
    }
}
